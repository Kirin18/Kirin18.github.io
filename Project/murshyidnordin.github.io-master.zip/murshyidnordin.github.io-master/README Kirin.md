# murshyidnordin.github.io
Group Kirin
‘Click Event’
Prepared by SYED MOHAMMED KHALID (1718487),MOHAMAD MURSHYID BIN MAT NORDIN	(1710279) and ADAM IZZUDDIN BIN KHALID  (1627111)

‘Click Event’ is a website for booking venues or equipments in IIUM that open to students and staffs.
1. Group Contributions
Each of the team members prepared 4 web pages for the progress presentation
as shown in Table 1.

2. Future enhancement
A list of completed products (at least 8 products per pages) will be displayed
during the final presentation. Future enhancement shall also include
interactions and storage of data. Contributions are
shown in Group COntribution


Group Contribution
Name       Contributions 
Khalid  > • Pages: Home page, Gallery, Report Venue, Report Equipments and Booking Equipment form 
          • Web elements: Navigation bar
Future enhancements    • Make sure all links in all pages is working
                       •Add more grapgical aspect
                       •Add more pictures to Gallery
                       •Add a backend service to all the pages where it is required



Murshyid  >     • Pages: About Us, List Rental Fees,Choose Equipments, Check Equipments Availibility
                 • Web elements: Logo
Future enhancements        • Adding more feature and apply good color for texts and boxes. 
                             • Choose better and high quality image and Apply event handler taht function to link between the pages
                           • JavaScript event handlers for Check Availibilty and storage of data using JSON to check current status of the equipment
 Adam >        •Pages:Contact Us, Booking Venue, Check Venue Availibility
               • Web elements: social media logo
 Future enhancements     • Adding checkout form of the venue booking and checking availability of the venues
                  
                           
3. Use of third party resources
JQueryUI: Team member Murshyid uses the accordion widget for the List Rental Fees page and Khalid uses datepicker for report and booking form.

Graphics: Team members Khalid, Murshyid and Adam obtained all graphics for the Catalogues from
hiveminer.com,foursqure.com. Those websites provide some hight quality picture.

Web elements       Team members                  Modifications
Date picker        Khalid                     Resize font size and change color 
Accordion Widget   Murshyid                   Change background color and font size
Graphics          Khalid, Murshyid and Adam  All graphics are resized using CSS. 


Reference
Retrieved
Background image.Retrieved 30/10/2018 from https://hiveminer.com/Tags/iium,landscape
The JQuery Foundation. Accordion Widget. Retrieved 1/11/2018 from https://jqueryui.com/accordion/  
The JQuery Foundation.Retrieved 28/10/2018 from https://jqueryui.com/datepicker/
Retrieved 2/11/2018 from https://www.w3schools.com/html/html_form_input_types.asp
Logo image.Retrieved 3/11/2018 from https://www.canva.com/
Retrieved 31/10/2018 from https://www.w3schools.com/howto/howto_css_checkout_form.asp
Retrieved 1/11/2018 from http://www.htmlandcssbook.com/code-samples/chapter-15/



